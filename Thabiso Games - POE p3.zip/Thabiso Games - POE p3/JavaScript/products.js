// ===================== FANCY BRIGHT STYLING =====================

// Add CSS styles dynamically using JavaScript
const style = document.createElement("style");
style.textContent = `
/* Global body */
body {
  margin: 0;
  font-family: 'Poppins', Arial, sans-serif;
  background: linear-gradient(135deg, #ff9a9e, #fad0c4);
  animation: bgShift 20s ease infinite alternate;
  color: #222;
}

@keyframes bgShift {
  0% { background: linear-gradient(135deg, #ff9a9e, #fad0c4); }
  50% { background: linear-gradient(135deg, #a18cd1, #fbc2eb); }
  100% { background: linear-gradient(135deg, #7df0ff, #ff7ae5); }
}

/* Header */
header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px 40px;
  background: linear-gradient(90deg, #ff00c8, #00eaff);
  border-radius: 0 0 20px 20px;
  box-shadow: 0 5px 25px rgba(0,0,0,0.5);
  animation: headerGlow 3s infinite alternate;
}

@keyframes headerGlow {
  0% { box-shadow: 0 5px 20px rgba(255,255,255,0.5); }
  50% { box-shadow: 0 5px 30px rgba(255,255,255,0.8); }
  100% { box-shadow: 0 5px 20px rgba(255,255,255,0.5); }
}

.logo {
  width: 80px;
  height: 80px;
  border-radius: 15px;
  border: 3px solid white;
  box-shadow: 0 0 20px white;
}

header h1 {
  font-size: 2rem;
  color: white;
  text-shadow: 2px 2px 10px black;
}

/* Navigation */
.nav-links {
  list-style: none;
  display: flex;
  gap: 20px;
}

.nav-links a {
  text-decoration: none;
  color: white;
  font-weight: bold;
  padding: 10px 15px;
  border-radius: 10px;
  background: rgba(255,255,255,0.15);
  transition: all 0.3s ease;
}

.nav-links a:hover {
  background: white;
  color: #ff00c8;
  transform: scale(1.1);
  box-shadow: 0 0 15px white;
}

.nav-links .active {
  background: yellow;
  color: black;
  box-shadow: 0 0 20px yellow;
}

/* Main content */
main {
  padding: 40px;
}

.welcome {
  background: rgba(255,255,255,0.5);
  padding: 30px;
  border-radius: 20px;
  box-shadow: 0 0 25px rgba(255,255,255,0.7);
  backdrop-filter: blur(10px);
  animation: fadeIn 2s ease-out;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(30px); }
  to { opacity: 1; transform: translateY(0); }
}

.welcome h2 {
  font-size: 2.4rem;
  color: #4b0082;
  text-shadow: 0 0 10px white;
}

video {
  width: 100%;
  border-radius: 15px;
  box-shadow: 0 0 25px rgba(0,0,0,0.4);
  margin: 20px 0;
}

/* Pricing box */
.pricing {
  background: linear-gradient(90deg, #ffea00, #ff7b00);
  padding: 12px;
  border-radius: 12px;
  font-weight: bold;
  font-size: 1.3rem;
  color: black;
  box-shadow: 0 0 20px orange;
}

/* Footer */
footer {
  background: black;
  color: white;
  text-align: center;
  padding: 20px;
  font-weight: 600;
  letter-spacing: 1px;
  box-shadow: 0 -5px 20px rgba(0,0,0,0.5);
  margin-top: 40px;
}
`;
document.head.appendChild(style);

// ======================= CONTAINER ==========================  
const app = document.getElementById("app");

// ======================= HEADER =============================
// Logo container
const header = document.createElement("header");
const logoContainer = document.createElement("div");
logoContainer.className = "logo-container";

const logo = document.createElement("img");
logo.src = "images/Logo.png";
logo.alt = "THABISO GAMES Logo";
logo.className = "logo";

const h1 = document.createElement("h1");
h1.textContent = "THABISO GAMES";

logoContainer.appendChild(logo);
logoContainer.appendChild(h1);

// Navigation
const nav = document.createElement("nav");
const navList = document.createElement("ul");
navList.className = "nav-links";

const menuItems = [
  { name: "Home", url: "home.html", active: true },
  { name: "About Us", url: "about.html" },
  { name: "Products & Services", url: "products.html" },
  { name: "News Updates", url: "news.html" },
  { name: "Contact Us", url: "contact.html" },
];

menuItems.forEach(item => {
  const li = document.createElement("li");
  const a = document.createElement("a");
  a.textContent = item.name;
  a.href = item.url;
  if (item.active) a.classList.add("active");
  li.appendChild(a);
  navList.appendChild(li);
});

nav.appendChild(navList);
header.appendChild(logoContainer);
header.appendChild(nav);

// ======================= MAIN ===============================
const main = document.createElement("main");
const welcomeSection = document.createElement("section");
welcomeSection.className = "welcome";

const heading = document.createElement("h2");
heading.textContent = "Welcome to THABISO GAMES";

// Video
const video = document.createElement("video");
video.controls = true;
const source = document.createElement("source");
source.src = "images/Aa.mp4";
source.type = "video/mp4";
video.appendChild(source);

// Paragraphs
const p1 = document.createElement("p");
p1.textContent =
  "We are your number one store for affordable game rentals. Rent the latest PC and PlayStation titles at the best prices.";

const pricing = document.createElement("p");
pricing.className = "pricing";
pricing.innerHTML =
  "<strong>Rental Pricing:</strong> R250 for 3 days + R100 for each extra day.";

welcomeSection.appendChild(heading);
welcomeSection.appendChild(video);
welcomeSection.appendChild(p1);
welcomeSection.appendChild(pricing);
main.appendChild(welcomeSection);

// ====================== FOOTER ==============================
const footer = document.createElement("footer");
const footText = document.createElement("p");
footText.innerHTML = "&copy; 2025 THABISO GAMES. All Rights Reserved.";
footer.appendChild(footText);

// =================== ATTACH TO APP ==========================
app.appendChild(header);
app.appendChild(main);
app.appendChild(footer);

console.log("Fancy bright theme applied with JavaScript!");
