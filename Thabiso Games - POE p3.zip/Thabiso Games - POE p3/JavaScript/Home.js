// ===================== FANCY BRIGHT STYLING =====================

// Create a <style> element with modern CSS styling
const fancyStyle = document.createElement("style");
fancyStyle.innerHTML = `
/* GLOBAL BODY */
body {
  margin: 0;
  font-family: 'Poppins', Arial, sans-serif;
  background: linear-gradient(135deg, #ff7ae5, #7df0ff);
  animation: bgAnimation 15s ease infinite alternate;
  color: #222;
}

@keyframes bgAnimation {
  0% { background: linear-gradient(135deg, #ff9a9e, #fad0c4); }
  50% { background: linear-gradient(135deg, #a18cd1, #fbc2eb); }
  100% { background: linear-gradient(135deg, #7df0ff, #ff7ae5); }
}

/* HEADER */
header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px 40px;
  background: linear-gradient(90deg, #ff00c8, #00eaff);
  box-shadow: 0 5px 20px rgba(0,0,0,0.4);
  border-radius: 0 0 20px 20px;
  animation: headerGlow 3s infinite alternate;
}

@keyframes headerGlow {
  0% { box-shadow: 0 5px 20px rgba(255,255,255,0.5); }
  50% { box-shadow: 0 5px 30px rgba(255,255,255,0.8); }
  100% { box-shadow: 0 5px 20px rgba(255,255,255,0.5); }
}

.logo {
  width: 80px;
  height: 80px;
  border-radius: 15px;
  border: 3px solid white;
  box-shadow: 0 0 20px white;
}

header h1 {
  font-size: 2.2rem;
  font-weight: 900;
  color: white;
  text-shadow: 2px 2px 10px black;
}

/* NAVIGATION */
.nav-links {
  list-style: none;
  display: flex;
  gap: 20px;
}

.nav-links a {
  text-decoration: none;
  color: white;
  font-weight: 700;
  padding: 10px 16px;
  border-radius: 10px;
  background: rgba(255,255,255,0.15);
  transition: all 0.3s ease;
}

.nav-links a:hover {
  background: white;
  color: #ff00c8;
  transform: scale(1.15);
  box-shadow: 0 0 15px white;
}

.nav-links .active {
  background: yellow;
  color: black;
  box-shadow: 0 0 20px yellow;
}

/* MAIN CONTENT */
main {
  padding: 40px;
}

.welcome {
  background: rgba(255,255,255,0.5);
  padding: 30px;
  border-radius: 20px;
  box-shadow: 0 0 25px rgba(255,255,255,0.7);
  backdrop-filter: blur(10px);
  animation: fadeIn 2s ease-out;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(30px); }
  to { opacity: 1; transform: translateY(0); }
}

.welcome h2 {
  font-size: 2.4rem;
  text-shadow: 0 0 10px white;
  color: #4b0082;
}

video {
  width: 100%;
  border-radius: 15px;
  box-shadow: 0 0 25px rgba(0,0,0,0.4);
  margin: 20px 0;
}

/* PRICING BOX */
.pricing {
  background: linear-gradient(90deg, #ffea00, #ff7b00);
  padding: 12px;
  border-radius: 12px;
  color: black;
  font-size: 1.3rem;
  font-weight: bold;
  box-shadow: 0 0 20px orange;
}

/* FOOTER */
footer {
  background: black;
  color: white;
  text-align: center;
  padding: 20px;
  font-weight: 600;
  letter-spacing: 1px;
  box-shadow: 0 -5px 20px rgba(0,0,0,0.5);
  margin-top: 40px;
}

/* BUTTON & INTERACTIONS (optional) */
button {
  padding: 12px 20px;
  border: none;
  border-radius: 12px;
  font-weight: 700;
  background: linear-gradient(90deg, #ff00c8, #00eaff);
  color: white;
  cursor: pointer;
  transition: all 0.3s ease;
  box-shadow: 0 0 15px rgba(255,255,255,0.6);
}

button:hover {
  transform: scale(1.1);
  box-shadow: 0 0 25px rgba(255,255,255,0.9);
}
`;

// Append the style to the document head
document.head.appendChild(fancyStyle);

console.log("Fancy bright theme applied with JavaScript!");
