// ===================== ADD STYLING VIA JS ======================
const style = document.createElement("style");
style.textContent = `
body {
    margin: 0;
    font-family: 'Poppins', Arial, sans-serif;
    background: linear-gradient(135deg, #ff9a9e, #fad0c4);
    animation: bgShift 20s ease infinite alternate;
    color: #222;
}

@keyframes bgShift {
    0% { background: linear-gradient(135deg, #ff9a9e, #fad0c4); }
    50% { background: linear-gradient(135deg, #a18cd1, #fbc2eb); }
    100% { background: linear-gradient(135deg, #7df0ff, #ff7ae5); }
}

header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 20px 40px;
    background: linear-gradient(90deg, #ff00c8, #00eaff);
    border-radius: 0 0 20px 20px;
    box-shadow: 0 5px 25px rgba(0,0,0,0.5);
}

header h1 {
    color: white;
    text-shadow: 2px 2px 10px black;
}

header .logo img {
    width: 80px;
    border-radius: 15px;
    box-shadow: 0 0 20px white;
}

.nav-links {
    list-style: none;
    display: flex;
    gap: 20px;
}

.nav-links a {
    text-decoration: none;
    color: white;
    font-weight: bold;
    padding: 10px 15px;
    border-radius: 10px;
    transition: all 0.3s ease;
}

.nav-links a:hover, .nav-links .active {
    background: yellow;
    color: black;
    box-shadow: 0 0 15px yellow;
}

main {
    padding: 40px;
    display: flex;
    flex-direction: column;
    align-items: center;
}

main h2 {
    font-size: 2rem;
    color: #4b0082;
    text-shadow: 0 0 10px white;
}

#searchNews {
    padding: 12px;
    width: 50%;
    max-width: 300px;
    margin: 20px 0;
    border-radius: 12px;
    border: none;
    box-shadow: 0 0 15px rgba(0,0,0,0.3);
    font-size: 1rem;
}

.news-list {
    list-style: none;
    padding: 0;
    width: 80%;
    max-width: 600px;
}

.news-list li {
    background: rgba(255,255,255,0.5);
    margin: 10px 0;
    padding: 15px;
    border-radius: 15px;
    box-shadow: 0 0 20px rgba(0,0,0,0.2);
    transition: all 0.3s ease;
}

.news-list li:hover {
    transform: scale(1.05);
    background: rgba(255,255,255,0.8);
    box-shadow: 0 0 25px rgba(255,255,0,0.7);
}

footer {
    background: black;
    color: white;
    text-align: center;
    padding: 20px;
    font-weight: 600;
    margin-top: 40px;
}
`;
document.head.appendChild(style);

// ===================== DATA (Dynamic Content) ======================
const newsItems = [
    { date: "August 2025", text: "New FIFA and Call of Duty titles available!" },
    { date: "July 2025", text: "Rent 5 games and get 1 free day." },
    { date: "June 2025", text: "New stock of PlayStation 5 controllers added." }
];

// ===================== CREATE HEADER ======================
function createHeader() {
    return `
    <header>
        <div class="logo">
            <img src="images/Logo.png" alt="THABISO GAMES Logo">
        </div>
        <h1>THABISO GAMES</h1>
        <nav>
            <ul class="nav-links">
                <li><a href="home.html">Home</a></li>
                <li><a href="about.html">About Us</a></li>
                <li><a href="products.html">Products & Services</a></li>
                <li><a class="active" href="news.html">News Updates</a></li>
                <li><a href="contact.html">Contact Us</a></li>
            </ul>
        </nav>
    </header>
    `;
}

// ===================== CREATE NEWS LIST ======================
function renderNewsList(filterText = "") {
    let filteredNews = newsItems.filter(item =>
        item.text.toLowerCase().includes(filterText.toLowerCase()) ||
        item.date.toLowerCase().includes(filterText.toLowerCase())
    );

    if (filteredNews.length === 0) return `<p>No news found.</p>`;

    return `
        <ul class="news-list">
            ${filteredNews.map(item => `<li><strong>${item.date}:</strong> ${item.text}</li>`).join("")}
        </ul>
    `;
}

// ===================== CREATE MAIN CONTENT ======================
function createMainContent() {
    return `
        <main>
            <h2>Latest News</h2>
            <p>Stay updated with our latest promotions and game arrivals:</p>
            <input type="text" id="searchNews" placeholder="Search news...">
            <div id="newsContainer">${renderNewsList()}</div>
        </main>
    `;
}

// ===================== CREATE FOOTER ======================
function createFooter() {
    const year = new Date().getFullYear();
    return `<footer><p>&copy; ${year} THABISO GAMES. All Rights Reserved.</p></footer>`;
}

// ===================== RENDER PAGE ======================
document.getElementById("app").innerHTML =
    createHeader() + createMainContent() + createFooter();

// ===================== SEARCH FUNCTIONALITY ======================
document.getElementById("searchNews").addEventListener("input", function () {
    document.getElementById("newsContainer").innerHTML = renderNewsList(this.value);
});
