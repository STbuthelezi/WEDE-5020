// ===================== ADD STYLING VIA JS ======================
const style = document.createElement("style");
style.textContent = `
body {
    margin: 0;
    font-family: 'Poppins', Arial, sans-serif;
    background: linear-gradient(135deg, #ff9a9e, #fad0c4);
    animation: bgShift 20s ease infinite alternate;
    color: #222;
}

@keyframes bgShift {
    0% { background: linear-gradient(135deg, #ff9a9e, #fad0c4); }
    50% { background: linear-gradient(135deg, #a18cd1, #fbc2eb); }
    100% { background: linear-gradient(135deg, #7df0ff, #ff7ae5); }
}

header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 20px 40px;
    background: linear-gradient(90deg, #ff00c8, #00eaff);
    border-radius: 0 0 20px 20px;
    box-shadow: 0 5px 25px rgba(0,0,0,0.5);
}

header h1 {
    color: white;
    text-shadow: 2px 2px 10px black;
}

header .logo {
    width: 80px;
    border-radius: 15px;
    box-shadow: 0 0 20px white;
}

.nav-links {
    list-style: none;
    display: flex;
    gap: 20px;
}

.nav-links a {
    text-decoration: none;
    color: white;
    font-weight: bold;
    padding: 10px 15px;
    border-radius: 10px;
    transition: all 0.3s ease;
}

.nav-links a:hover, .nav-links .active {
    background: yellow;
    color: black;
    box-shadow: 0 0 15px yellow;
}

main {
    padding: 40px;
    display: flex;
    flex-direction: column;
    align-items: center;
}

main h2 {
    font-size: 2rem;
    color: #4b0082;
    text-shadow: 0 0 10px white;
}

.contact-info {
    background: rgba(255,255,255,0.6);
    padding: 20px;
    border-radius: 20px;
    margin-bottom: 30px;
    box-shadow: 0 0 20px rgba(0,0,0,0.3);
}

form {
    display: flex;
    flex-direction: column;
    gap: 15px;
    width: 100%;
    max-width: 500px;
}

form input, form select, form textarea {
    padding: 12px;
    border-radius: 12px;
    border: none;
    box-shadow: 0 0 10px rgba(0,0,0,0.2);
    font-size: 1rem;
    transition: all 0.3s ease;
}

form input:focus, form select:focus, form textarea:focus {
    outline: none;
    box-shadow: 0 0 20px #ff00c8;
}

form button {
    padding: 15px;
    font-size: 1.1rem;
    font-weight: bold;
    border: none;
    border-radius: 15px;
    background: linear-gradient(90deg, #ff00c8, #00eaff);
    color: white;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 0 15px #00eaff;
}

form button:hover {
    transform: scale(1.05);
    box-shadow: 0 0 25px #ff00c8;
}

.map-container {
    width: 100%;
    max-width: 600px;
    margin-top: 30px;
    border-radius: 20px;
    overflow: hidden;
    box-shadow: 0 0 25px rgba(0,0,0,0.4);
}

footer {
    background: black;
    color: white;
    text-align: center;
    padding: 20px;
    font-weight: 600;
    margin-top: 40px;
}
`;
document.head.appendChild(style);

// ===================== SEO Metadata ======================
document.head.insertAdjacentHTML("beforeend", `
    <meta name="description" content="Contact Thabiso Games for enquiries, support, and general communication.">
    <meta name="keywords" content="gaming contact, Thabiso Games contact, customer support, Johannesburg gaming store">
`);

// ===================== HEADER ======================
function createHeader() {
    return `
    <header>
        <div class="logo-container">
            <img src="images/Logo.png" alt="THABISO GAMES Logo" class="logo">
            <h1>THABISO GAMES</h1>
        </div>

        <nav>
            <ul class="nav-links">
                <li><a href="home.html">Home</a></li>
                <li><a href="about.html">About Us</a></li>
                <li><a href="products.html">Products & Services</a></li>
                <li><a href="news.html">News Updates</a></li>
                <li><a class="active" href="contact.html">Contact Us</a></li>
            </ul>
        </nav>
    </header>
    `;
}

// ===================== CONTACT FORM ======================
function createForm() {
    return `
    <main>
        <h2>Contact Us</h2>

        <div class="contact-info">
            <p><strong>Email:</strong> info@thabisogames.co.za</p>
            <p><strong>Phone:</strong> +27 71 234 5678</p>
            <p><strong>Business Hours:</strong> Mon - Sat, 08:00 AM - 16:30 PM</p>
            <p><strong>Address:</strong> 123 Gaming Street, Johannesburg, South Africa</p>
        </div>

        <h3>Send us a message</h3>

        <form id="contactForm">
            <input type="text" id="name" placeholder="Full Name" required>
            <input type="email" id="email" placeholder="Email Address" required>
            <input type="text" id="phone" placeholder="Phone Number" required>
            
            <select id="messageType" required>
                <option value="">Select message type</option>
                <option value="General Question">General Question</option>
                <option value="Support">Support</option>
                <option value="Business Opportunity">Business Opportunity</option>
            </select>

            <textarea id="message" placeholder="Your message..." rows="5" required></textarea>

            <button type="submit">Send Message</button>

            <p id="formResponse"></p>
        </form>

        <div class="map-container">
            <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d114710.88750288856!2d28.0284293!3d-26.0689301!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1e950c23b9374d43%3A0x92a4d0c2d1d1eeb9!2sWoodmead%2C%20Sandton%2C%202191!5e0!3m2!1sen!2sza!4v1691942904856!5m2!1sen!2sza"
                allowfullscreen 
                loading="lazy"
                referrerpolicy="no-referrer-when-downgrade">
            </iframe>
        </div>
    </main>
    `;
}

// ===================== FOOTER ======================
function createFooter() {
    const year = new Date().getFullYear();
    return `
        <footer>
            <p>&copy; ${year} THABISO GAMES. All Rights Reserved.</p>
        </footer>
    `;
}

// ===================== RENDER PAGE ======================
document.getElementById("app").innerHTML =
    createHeader() +
    createForm() +
    createFooter();

// ===================== FORM VALIDATION ======================
document.getElementById("contactForm").addEventListener("submit", function (e) {
    e.preventDefault();

    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const phone = document.getElementById("phone").value.trim();
    const type = document.getElementById("messageType").value;
    const message = document.getElementById("message").value.trim();
    const responseBox = document.getElementById("formResponse");

    const phonePattern = /^[0-9]{10}$/;
    if (!phonePattern.test(phone)) {
        responseBox.style.color = "red";
        responseBox.textContent = "Phone number must be 10 digits.";
        return;
    }

    if (message.length < 10) {
        responseBox.style.color = "red";
        responseBox.textContent = "Message must be at least 10 characters.";
        return;
    }

    const emailBody = `
Name: ${name}
Email: ${email}
Phone: ${phone}
Type: ${type}
Message: ${message}
    `;

    console.log("EMAIL SENT TO: info@thabisogames.co.za");
    console.log(emailBody);

    responseBox.style.color = "green";
    responseBox.textContent = "Your message has been sent successfully!";

    this.reset();
});
