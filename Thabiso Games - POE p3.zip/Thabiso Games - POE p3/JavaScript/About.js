// ===================== DYNAMIC STYLING ======================
const style = document.createElement("style");
style.textContent = `
body {
    margin: 0;
    font-family: 'Poppins', Arial, sans-serif;
    background: linear-gradient(135deg, #ff9a9e, #fad0c4);
    animation: bgShift 25s ease infinite alternate;
    color: #222;
}

@keyframes bgShift {
    0% { background: linear-gradient(135deg, #ff9a9e, #fad0c4); }
    50% { background: linear-gradient(135deg, #a18cd1, #fbc2eb); }
    100% { background: linear-gradient(135deg, #7df0ff, #ff7ae5); }
}

header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 20px 40px;
    background: linear-gradient(90deg, #ff00c8, #00eaff);
    border-radius: 0 0 20px 20px;
    box-shadow: 0 5px 25px rgba(0,0,0,0.5);
}

header h1 {
    color: white;
    text-shadow: 2px 2px 10px black;
}

header .logo {
    width: 80px;
    border-radius: 15px;
    box-shadow: 0 0 20px white;
}

.nav-links {
    list-style: none;
    display: flex;
    gap: 20px;
}

.nav-links a {
    text-decoration: none;
    color: white;
    font-weight: bold;
    padding: 10px 15px;
    border-radius: 10px;
    transition: all 0.3s ease;
}

.nav-links a:hover, .nav-links .active {
    background: yellow;
    color: black;
    box-shadow: 0 0 15px yellow;
}

.hero {
    position: relative;
    overflow: hidden;
    max-height: 400px;
    border-radius: 20px;
    margin: 30px auto;
    max-width: 90%;
    box-shadow: 0 0 25px rgba(0,0,0,0.5);
}

.hero img {
    width: 100%;
    display: block;
    border-radius: 20px;
    transition: transform 0.5s ease;
}

.hero img:hover {
    transform: scale(1.05);
}

main {
    padding: 40px;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 30px;
}

h2 {
    font-size: 2.2rem;
    color: #4b0082;
    text-shadow: 0 0 10px white;
}

p {
    max-width: 800px;
    line-height: 1.6;
    text-align: center;
    font-size: 1.1rem;
}

.gallery {
    display: flex;
    gap: 20px;
    flex-wrap: wrap;
    justify-content: center;
}

.lightbox-img {
    width: 200px;
    height: 120px;
    object-fit: cover;
    border-radius: 15px;
    cursor: pointer;
    box-shadow: 0 0 15px rgba(0,0,0,0.3);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.lightbox-img:hover {
    transform: scale(1.05);
    box-shadow: 0 0 25px #ff00c8;
}

footer {
    background: black;
    color: white;
    text-align: center;
    padding: 20px;
    font-weight: 600;
    margin-top: 40px;
    border-radius: 20px 20px 0 0;
}

/* Lightbox styles */
.lightbox-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.9);
    display: flex;
    justify-content: center;
    align-items: center;
    cursor: pointer;
    z-index: 9999;
}

.lightbox-overlay img {
    max-width: 80%;
    max-height: 80%;
    border-radius: 15px;
    box-shadow: 0 0 25px white;
    transition: transform 0.3s ease;
}

.lightbox-overlay img:hover {
    transform: scale(1.05);
}
`;
document.head.appendChild(style);

// ===================== SEO & TITLE ======================
document.title = "THABISO GAMES | About";
const metaDesc = document.createElement("meta");
metaDesc.name = "description";
metaDesc.content = "About THABISO GAMES - Affordable game rentals for PC and PlayStation.";
document.head.appendChild(metaDesc);

// ===================== HEADER ======================
const header = document.createElement("header");

const logoContainer = document.createElement("div");
logoContainer.className = "logo-container";

const logo = document.createElement("img");
logo.src = "images/Logo.png";
logo.alt = "THABISO GAMES Logo";
logo.className = "logo";

const title = document.createElement("h1");
title.textContent = "THABISO GAMES";

logoContainer.appendChild(logo);
logoContainer.appendChild(title);

const nav = document.createElement("nav");
const ul = document.createElement("ul");
ul.className = "nav-links";

const navItems = [
  { name: "Home", link: "home.html" },
  { name: "About Us", link: "about.html", active: true },
  { name: "Products & Services", link: "products.html" },
  { name: "News Updates", link: "news.html" },
  { name: "Contact Us", link: "contact.html" }
];

navItems.forEach(item => {
  const li = document.createElement("li");
  const a = document.createElement("a");
  a.href = item.link;
  a.textContent = item.name;
  if (item.active) a.classList.add("active");
  li.appendChild(a);
  ul.appendChild(li);
});

nav.appendChild(ul);
header.appendChild(logoContainer);
header.appendChild(nav);
document.body.appendChild(header);

// ===================== HERO ======================
const hero = document.createElement("section");
hero.className = "hero";

const heroImg = document.createElement("img");
heroImg.src = "images/D.webp";
heroImg.alt = "About THABISO GAMES";

hero.appendChild(heroImg);
document.body.appendChild(hero);

// ===================== MAIN ======================
const main = document.createElement("main");

const h2 = document.createElement("h2");
h2.textContent = "Welcome to THABISO GAMES";

const p1 = document.createElement("p");
p1.textContent =
  "We are your number one store for affordable game rentals. Rent the latest PC and PlayStation titles at the best prices.";

const gallery = document.createElement("section");
gallery.className = "gallery";

const galleryImages = [
  { src: "images/E.JPG", alt: "Game Rental Sample" },
  { src: "images/F.JPG", alt: "PlayStation Rental Sample" }
];

galleryImages.forEach(imgItem => {
  const img = document.createElement("img");
  img.src = imgItem.src;
  img.alt = imgItem.alt;
  img.className = "lightbox-img";

  img.addEventListener("click", () => showLightbox(imgItem.src));
  gallery.appendChild(img);
});

const p2 = document.createElement("p");
p2.innerHTML = "<strong>Rental Pricing:</strong> R250 for 3 days + R100 for each extra day.";

main.appendChild(h2);
main.appendChild(p1);
main.appendChild(gallery);
main.appendChild(p2);
document.body.appendChild(main);

// ===================== FOOTER ======================
const footer = document.createElement("footer");
footer.innerHTML = "<p>&copy; 2025 THABISO GAMES. All Rights Reserved.</p>";
document.body.appendChild(footer);

// ===================== LIGHTBOX ======================
function showLightbox(imageSrc) {
  const overlay = document.createElement("div");
  overlay.className = "lightbox-overlay";

  const img = document.createElement("img");
  img.src = imageSrc;

  overlay.appendChild(img);

  overlay.addEventListener("click", () => overlay.remove());

  document.body.appendChild(overlay);
}
